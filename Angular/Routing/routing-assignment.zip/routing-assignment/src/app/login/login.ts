import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Router } from '@angular/router';
import DOMPurify from 'dompurify';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, MatFormFieldModule, MatInputModule, CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  private authService = inject(AuthService);
  private router = inject(Router);
  invalidCredentials = false;

  onChangeInput() {
    this.invalidCredentials = false;
  }

  onSubmit(formData: NgForm) {
    if (formData.valid) {
      const enteredEmail = DOMPurify.sanitize(formData.form.value.email);
      const enteredPassword = DOMPurify.sanitize(formData.form.value.password);
      console.log(enteredEmail, enteredPassword);
      if (this.authService.login(enteredEmail, enteredPassword)) {
        this.router.navigate(['']);
        formData.form.reset();
      } else {
        this.invalidCredentials = true;
      }
    }
  }
}
