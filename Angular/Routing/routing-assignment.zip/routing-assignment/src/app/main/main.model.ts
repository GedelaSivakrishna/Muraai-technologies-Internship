export interface Gender {
    value: string,
    viewValue: string
}

export interface State {
    value: string,
    viewValue: string
}

export interface PeriodicElement {
    id: number,
    firstName: string;
    lastName: string;
    email: string;
    gender: string;
    password: string;
    confirmPassword: string;
    state: string;
    city: string;
    pincode: string;
    phone: string;
  }
  

