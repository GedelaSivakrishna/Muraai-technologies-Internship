import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { passwordMatchValidator } from '../validators/password-match.validator';
import { type Gender, type PeriodicElement, type State } from './main.model';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { UserService } from '../services/user.service';

// const ELEMENT_DATA: PeriodicElement[] = ;

@Component({
  selector: 'app-main',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    CommonModule,
    ReactiveFormsModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule
  ],
  templateUrl: './main.html',
  styleUrl: './main.css',
})
export class Main {

  userService: UserService = inject(UserService);
  displayedColumns: string[] = ["firstName", "lastName", "email", "gender", "state", "city", "pincode", "phone", "edit", "delete"];
  dataSource = new MatTableDataSource<PeriodicElement>(this.userService.getUsers());

  form = new FormGroup({
    firstName: new FormControl('', {
      validators: [Validators.required],
    }),
    lastName: new FormControl('', {
      validators: [Validators.required],
    }),
    email: new FormControl('', {
      validators: [
        Validators.email,
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$'),
      ],
    }),
    gender: new FormControl<'male' | 'female' | 'others'>('male', {
      validators: [Validators.required],
    }),
    passwords: new FormGroup(
      {
        password: new FormControl('', {
          validators: [Validators.required, Validators.minLength(6)],
        }),
        confirmPassword: new FormControl('', {
          validators: [Validators.required],
        }),
      },
      { validators: passwordMatchValidator() }
    ),
    address: new FormGroup({
      state: new FormControl<
        'odisha' | 'karnataka' | 'andrapradesh' | 'tamilnadu' | 'maharashtra'
      >('odisha', {
        validators: [Validators.required],
      }),
      city: new FormControl('', {
        validators: [Validators.required],
      }),
      pincode: new FormControl('', {
        validators: [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(6),
        ],
      }),
      phone: new FormControl('', {
        validators: [
          Validators.required,
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      }),
    }),
  });
  submitted = false;
  updating = false;
  lastObj = this.dataSource.data.at(-1);
  id = this.lastObj ? this.lastObj.id : 1;

  genders: Gender[] = [
    { value: 'male', viewValue: 'Male' },
    { value: 'female', viewValue: 'Female' },
    { value: 'others', viewValue: 'Other' },
  ];

  states: State[] = [
    { value: 'odisha', viewValue: 'Odisha' },
    { value: 'karnataka', viewValue: 'karnataka' },
    { value: 'tamilnadu', viewValue: 'Tamilnadu' },
    { value: 'andrapradesh', viewValue: 'Andra Pradesh' },
    { value: 'maharashtra', viewValue: 'Maharashtra' },
  ];

  get firstName() {
    return this.form.controls.firstName;
  }

  get lastName() {
    return this.form.controls.lastName;
  }

  get email() {
    return this.form.controls.email;
  }

  get password() {
    return this.form.controls.passwords.controls.password;
  }

  get confirmPassword() {
    return this.form.controls.passwords.controls.confirmPassword;
  }

  get passwords() {
    return this.form.controls.passwords as FormGroup;
  }

  get city() {
    return this.form.controls.address.controls.city;
  }

  get pincode() {
    return this.form.controls.address.controls.pincode;
  }

  get phone() {
    return this.form.controls.address.controls.phone;
  }

  onChangeInput() {}

  onSubmit() {
    this.submitted = true;
    if (this.form.valid) {
      const formValues = this.form.value;
      // let idExists: boolean = ELEMENT_DATA.find(user => user.id === formValues.) 
      ++this.id;
      const newRow = {
        id: this.id,
        firstName: formValues.firstName!,
        lastName: formValues.lastName!,
        email: formValues.email!,
        gender: formValues.gender!,
        password: formValues.passwords?.password!,
        confirmPassword: formValues.passwords?.confirmPassword!,
        state: formValues.address?.state!,
        city: formValues.address?.city!,
        pincode: formValues.address?.pincode!,
        phone: formValues.address?.phone!,
      }
      
      this.dataSource.data = this.userService.addUser(newRow);
      // console.log(ELEMENT_DATA);
      // console.log(formValues);
      this.form.reset({
        firstName: '',
        lastName: '',
        email: '',
        gender: 'male',
        passwords: {
          password: '',
          confirmPassword: '',
        },
        address: {
          state: 'odisha',
          city: '',
          pincode: '',
          phone: '',
        },
      });
      this.submitted = false;
      this.updating = false;
      // this.form.markAsPristine();
      // this.form.markAsUntouched();
      // this.form.updateValueAndValidity();
    } 
  }

  onEdit(element: PeriodicElement) {
    this.updating = true;
    let row = this.dataSource.data.filter(user => user.email === element.email)[0];
    console.log("Row to be updated = " + row.email);
    this.form.patchValue({
    firstName: element.firstName,
    lastName: element.lastName,
    email: element.email,
    gender: element.gender as 'male' | 'female' | 'others',
    // element.gender as 'male' | 'female' | 'others' tells typescript that 
    // element.gender is of type 'male' | 'female' | 'others'
    address: {
      state: element.state as 'odisha' | 'karnataka' | 'andrapradesh' | 'tamilnadu' | 'maharashtra',
      city: element.city,
      pincode: element.pincode,
      phone: element.phone
    },
    passwords: {
      password: element.password,
      confirmPassword: element.confirmPassword,
    }
    });
    this.dataSource.data = this.userService.removeUser(row);
  }

  onDelete(element: PeriodicElement) {
    this.dataSource.data = this.userService.removeUser(element);
  }

}
