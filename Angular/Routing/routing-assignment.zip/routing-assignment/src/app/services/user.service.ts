import { Injectable } from "@angular/core";
import { type PeriodicElement } from "../main/main.model";

@Injectable({
    providedIn: 'root'
})
export class UserService {

    storedUsers = localStorage.getItem("users");
    users: PeriodicElement[] = this.storedUsers ? JSON.parse(this.storedUsers) : [];

    getUsers() {
        return this.users;
    }

    addUser(user: PeriodicElement) {
        this.users.push(user);
        localStorage.setItem("users", JSON.stringify(this.users));
        return this.users;
    }

    removeUser(user: PeriodicElement) {
        this.users = this.users.filter(u => u.id !== user.id);
        localStorage.setItem("users", JSON.stringify(this.users));
        return this.users;
    }

    // updateUser(user: PeriodicElement) {
    //     this.users = this.users.map(u => u.id === user)
    // }

}