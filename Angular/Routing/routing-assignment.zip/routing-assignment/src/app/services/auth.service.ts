import { Injectable, OnInit } from "@angular/core";

const users: Map<string, string> = new Map();
      users.set("sivakrishna@gmail.com", "password");
      users.set("user@gmail.com", "password");
      users.set("adminsivakrishna@gmail.com", "password");

@Injectable({
    providedIn: 'root',
})
export class AuthService implements OnInit {

    ngOnInit(): void {
        localStorage.setItem("isLoggedIn", "false");
    }


    login(email: string, password: string) {
        if(users.get(email) && users.get(email) === password) {
            localStorage.setItem("isLoggedIn", "true");
            return true;
        }
        else {
            return false;
        }
    }

    logout() {
        localStorage.setItem("isLoggedIn", "false");
    }

    isAuthenticated() {
        return localStorage.getItem("isLoggedIn") === "true";
    }

}