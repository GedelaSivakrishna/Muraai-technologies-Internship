import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from "@angular/router";

@Component({
  selector: 'app-home',
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home  {

  private router = inject(Router);

  onLogoutClick() {
    localStorage.setItem("isLoggedIn", "false");
    this.router.navigate(['/login']);
    console.log("user logged out");
  }
}

